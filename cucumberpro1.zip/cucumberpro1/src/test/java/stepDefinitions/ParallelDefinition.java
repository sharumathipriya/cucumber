package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class ParallelDefinition {
	WebDriver driver;
	
	@Given("user on the site to test parallel")
	public void user_on_the_site_to_test_parallel() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Testing\\chromedriver.exe");
		 driver=new ChromeDriver();
	     Thread.sleep(3000);
	}

	@When("url is launched{string} to test parallel")
	public void url_is_launched_https_www_amazon_in_to_test_parallel(String url) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
			driver.navigate().to(url);
			Thread.sleep(3000);
			driver.manage().window().maximize();
			Thread.sleep(3000);
			
	    
	}

	@Then("close the site to test partallel")
	public void close_the_site_to_test_partallel() {
	    // Write code here that turns the phrase above into concrete actions
	   driver.close();
	}

	@When("url is launched{string}to test parallel")
	public void url_is_launched_https_www_flipkart_com_to_test_parallel(String url) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		driver.navigate().to(url);
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
	    
	}



}

package stepDefinitions;

public class Plugindefinition {

}

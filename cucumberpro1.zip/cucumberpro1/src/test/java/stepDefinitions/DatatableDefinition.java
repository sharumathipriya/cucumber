package stepDefinitions;

import java.util.List;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class DatatableDefinition {
	
	@Given("user is on sign up screen")
	public void user_is_on_sign_up_screen() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Given");
	}
	@Then("user enter details")
	public void user_enter_details(DataTable dataTable) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can regisList<A>a DataTableType.
	   List<List<String>>data=dataTable.asLists();
	   System.out.println(data.get(0).get(0)+" "+data.get(0).get(1));
	   System.out.println(data.get(1).get(0)+" "+data.get(1).get(1));
	   System.out.println(data.get(2).get(0)+" "+data.get(2).get(1));
	   
	}


}

package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SeleniumDef {
	WebDriver driver;
	

@Given("user is on sign up screen new")
public void user_is_on_sign_up_screen_new() throws InterruptedException {
    // Write code here that turns the phrase above into concrete actions
	 System.setProperty("webdriver.chrome.driver", "C:\\Testing\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(3000);
		 driver.navigate().to("https://www.makemytrip.com/");
		 Thread.sleep(3000);
		 driver.manage().window().maximize();
		Thread.sleep(3000);
		
		
	System.out.println("Given");
	JavascriptExecutor js=(JavascriptExecutor)driver;
	 js.executeScript("document.elementFromPoint(0,0).click()");
}
@When("user provides enters ph_no={string} new")
public void user_provides_enters_ph_no_new(String string) throws InterruptedException {
    
	 driver.findElement(By.id("username")).sendKeys(string);
	 Thread.sleep(3000);

}


@When("user clicks on continue new")
public void user_clicks_on_continue_new() throws InterruptedException {
	driver.findElement(By.xpath("//*[@data-cy='continueBtn']")).click();
	Thread.sleep(3000);
	
}
@Then("otp is sent {string} new")
public void otp_is_sent_new(String string) throws InterruptedException {
	driver.findElement(By.xpath("//*[@placeholder='Enter OTP here']")).sendKeys(string);
	Thread.sleep(3000);
}
@Then("user is able to login new")
public void user_is_able_to_login_new() throws InterruptedException {
	driver.findElement(By.xpath("//span[text()='Login']")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//span[text()='Verify & Create Account']")).click();
	 Thread.sleep(3000);
	 
   

}

	 
	
}



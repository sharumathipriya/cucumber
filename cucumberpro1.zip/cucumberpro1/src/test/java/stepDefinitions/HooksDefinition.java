package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;

public class HooksDefinition {
	@Before("@smokeTest")
	public void beforeFeature()
	{
		System.out.println("Before Scenario");
	}
	@After("@smokeTest")
	public void afterFeature()
	{
		System.out.println("After Scenario");
	}
	
	/*@Before("@MobileTest")
	public void beforeMobileTest()
	{
		System.out.println("Before mobile test");
	}
	@After("@MobileTest")
	public void afterMobileTest()
	{
		System.out.println("After mobile test");
	}
	*/
	
	@Given("example of given one")
	public void example_of_given_one() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Given example one");
	}

	@When("example of when one")
	public void example_of_when_one() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("When example one");
	}

	@Then("example of then one")
	public void example_of_then_one() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Then example one");
	}

	@Given("example of given two")
	public void example_of_given_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Given example two");
	}

	@When("example of when two")
	public void example_of_when_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("When example two");
	}

	@Then("example of then two")
	public void example_of_then_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("Then example two");
	}




}
